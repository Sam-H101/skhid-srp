@echo off
start survarium_skhid.exe
